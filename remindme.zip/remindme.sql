-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2013 at 11:18 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;



-- --------------------------------------------------------

--
-- Table structure for table `todos`
--

CREATE TABLE IF NOT EXISTS `todos` (
  `title` varchar(255) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `dateset` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('Active','Not Active') NOT NULL DEFAULT 'Active',
  `priority` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `todos`
--

INSERT INTO `todos` (`title`, `description`, `dateset`, `status`, `priority`, `userId`, `id`) VALUES
('title1', 'desc1', '2013-12-11 17:16:02', 'Not Active', -1, 5, 1),
('title2', 'longdesc2 longdesc2 longdesc2 longdesc2 longdesc2 longdesc2 longdesc2 longdesc2 longdesc2 long', '2013-12-11 05:52:20', 'Not Active', -1, 5, 2),
('title3', 'My initial priority is 1', '2013-12-11 17:16:03', 'Not Active', -1, 5, 3),
('title5', 'inital p3', '2013-12-11 06:09:50', 'Not Active', -1, 5, 5),
('title6', 'initial p4', '2013-12-11 17:16:03', 'Not Active', -1, 5, 6),
('title7', 'initial p5', '2013-12-11 05:53:05', 'Not Active', -1, 5, 7),
('FOCS Review', 'Skim through class notes, script sheets, exams, and HWs', '2013-12-11 19:16:48', 'Active', 1, 5, 8),
('Multi Review', 'Skim through notes, tests, and do back exams', '2013-12-11 19:16:48', 'Active', 2, 5, 9),
('Pack up for the trip', '', '2013-12-11 19:16:48', 'Active', 3, 5, 10),
('Plan CSSA site', '', '2013-12-11 19:16:48', 'Active', 4, 5, 11),
('Style this site', '', '2013-12-11 19:16:48', 'Active', 0, 5, 12),
('test', 'test', '2013-12-11 21:13:38', 'Not Active', -1, 5, 13);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `salt`, `email`, `id`) VALUES
('test0', 'e45a84a1c99a825972d96f181b5d5945b27a18695593ccb99fb5784c3f4f8c3e', '1ead', 'test0@gmail.com', 5),
('test1', '753a6215fa3ee189988564b3478082777e9564ef6f66899efb70ad95c922a9c3', '1ae0', 'test1@gmail.com', 6);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `todos`
--
ALTER TABLE `todos`
  ADD CONSTRAINT `todos_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

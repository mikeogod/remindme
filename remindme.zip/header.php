<?php
ob_start();
?>
<?php if(!isset($_SESSION["user_remindme"])): ?>
  <div id="register">
    <form action="index.php" method="post">
      <label>user name: </label><input type="text" name="username" /><br />
      <label>password: </label><input type="password" name="password" /><br />
      <label>password again: </label><input type="password" name="password_again" /><br />
      <label>email: </label><input type="email" name="email" /><br />
      <input type="submit" name="register" value="Register!" /><br />
    </form>
  </div>
  <div id="login">
    <form action="index.php" method="post">
      <label>user name: </label><input type="text" name="username"/><br />
      <label>password: </label><input type="password" name="password" /><br />
      <br />
      <br />
      <input type="submit" name="login" value="Login!" /><br />
    </form>
  </div>
<?php else: ?>
  <div id="user_info">
    <p>Want to change your email address to send timely notifications?</p>
    <form action="index.php" method="post">
      <input type="email" name="email" size="40" placeholder="Type your new email address here..."/><br />
      <input type="password" name="password" size="40" placeholder="Type your password here..."/><br />
      <input type="submit" name="change_email" value="submit" /><br />
    </form>
  </div>
  <div id="logout">
    <form action="index.php" method="post">
      <input type="submit" name="logout" value="Logout!" />
    </form>
  </div>
<?php endif; ?>